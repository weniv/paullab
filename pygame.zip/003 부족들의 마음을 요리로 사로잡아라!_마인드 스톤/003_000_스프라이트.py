import pygame as pg

def 스프라이트생성(이미지, 위치, hp=0, mp=0):
    스프라이트 = pg.sprite.Sprite()
    스프라이트.image = 이미지
    스프라이트.hp = hp
    스프라이트.mp = mp
    스프라이트.rect = 스프라이트.image.get_rect()
    스프라이트.rect.x, 스프라이트.rect.y = 위치[0], 위치[1]
    return 스프라이트

pg.init()

실행여부 = True
화면가로길이, 화면세로길이 = 500, 500
화면 = pg.display.set_mode([화면가로길이, 화면세로길이])
pg.display.set_caption('부족들의 마음을 요리로 사로잡아라!')

자바독이미지크기 = (238, 238)
자바독이미지 = pg.image.load('img/자바독_기본자세.png')
자바독이미지 = pg.transform.scale(자바독이미지, 자바독이미지크기)

자바독스프라이트 = 스프라이트생성(자바독이미지, (150, 150), 100, 10000)
# 화면.blit(자바독이미지, (150, 150))
화면.blit(자바독스프라이트.image, (자바독스프라이트.rect.x, 자바독스프라이트.rect.y))

print(자바독스프라이트.hp)
print(자바독스프라이트.mp)

while 실행여부:
    pg.display.update()

    for 이벤트 in pg.event.get():
        if 이벤트.type == pg.QUIT:
            실행여부 = False

pg.display.quit()