import pygame as pg

pg.init()

화면가로길이 = 600
화면세로길이 = 800

화면 = pg.display.set_mode((화면가로길이, 화면세로길이))
사각형 = pg.Rect(100, 100, 100, 50)
print(f'사각형의 left : {사각형.left}')
print(f'사각형의 top : {사각형.top}')
print(f'사각형의 centerx : {사각형.centerx}')
print(f'사각형의 centery : {사각형.centery}')
print(f'사각형의 topleft : {사각형.topleft}')
print(f'사각형의 size : {사각형.size}')
사각형.left = 400

pg.draw.rect(화면, (0, 0, 255), 사각형, 5)

pg.display.update()

while True:
    for 이벤트 in pg.event.get():
        if 이벤트.type == pg.QUIT:
            quit()