import pygame as pg

pg.init()

화면가로길이 = 600
화면세로길이 = 800

화면 = pg.display.set_mode((화면가로길이, 화면세로길이))

라이캣 = pg.image.load('licat.png')
화면.blit(라이캣, (100, 100), pg.Rect(0, 0, 400, 270))

pg.display.update()

while True:
    for 이벤트 in pg.event.get():
        if 이벤트.type == pg.QUIT:
            quit()