import pygame as pg

pg.init()

화면가로길이 = 600
화면세로길이 = 800

화면 = pg.display.set_mode((화면가로길이, 화면세로길이))

라이캣 = pg.image.load('licat.png')
줄어든라이캣 = pg.transform.scale(라이캣, (150, 220))
돌려진라이캣 = pg.transform.rotate(라이캣, 90)

돌려진라이캣_사각형 = 돌려진라이캣.get_rect()
돌려진라이캣_사각형.center = (250, 320)

화면.blit(돌려진라이캣, 돌려진라이캣_사각형)

pg.display.update()

while True:
    for 이벤트 in pg.event.get():
        if 이벤트.type == pg.QUIT:
            quit()