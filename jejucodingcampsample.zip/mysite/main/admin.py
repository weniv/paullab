from django.contrib import admin
from .models import Cafe

admin.site.register(Cafe)

#leehojun
#이호준1!