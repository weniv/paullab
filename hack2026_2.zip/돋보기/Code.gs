/**
 * Dream — Google Apps Script 배포용 서버 코드
 *
 * 사용 방법:
 * 1. script.google.com 에서 새 프로젝트 생성
 * 2. 이 파일 내용을 Code.gs 에 붙여넣기
 * 3. 파일 추가(+) → HTML → 이름을 "index" 로 만들고 index.html 내용 전체 붙여넣기
 * 4. 배포 → 새 배포 → 유형: 웹 앱 → 액세스 권한: "모든 사용자" → 배포
 * 5. 발급된 웹 앱 URL로 접속
 */
function doGet() {
  return HtmlService.createHtmlOutputFromFile("index")
    .setTitle("Dream — 제주 진로체험 프로그램 탐색")
    .addMetaTag("viewport", "width=device-width, initial-scale=1.0")
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}
