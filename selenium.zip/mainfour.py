from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from bs4 import BeautifulSoup
import time

path = "C:/crawling/chromedriver.exe"

driver = webdriver.Chrome(path)

driver.get('https://accounts.goorm.io/login?return_url=aHR0cHM6Ly9pZGUuZ29vcm0uaW8vbXk=')

id = driver.find_element_by_id("emailInput")
pw = driver.find_element_by_id("passwordInput")

id.send_keys("hujun2348@naver.com")
pw.send_keys("qkdnffoq1234!") #바울랩1234!


pw.send_keys(Keys.ENTER)

time.sleep(5)

#req = driver.page_source
req = driver.page_source.encode('cp949', errors='replace')
#soup = BeautifulSoup(req, 'html.parser', from_encoding='urf-8')
#req.encode('utf-8')
#req.encoding = 'utf-8'
print('hello')
#change = req.encode('utf-8')
#print(change)
#a = change.decode('euc-kr')
#a = change.decode('euc-kr')
#print(a)
soup = BeautifulSoup(req, 'html.parser')

print(soup)

l = []
for tag in soup.select('.container_name'):
    l.append(tag.text.strip())

print(l)

driver.close()
