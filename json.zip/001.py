from data import sample

#print(sample)
print(sample[0])
print(sample[0]['score']['math'])

#1. 모든 학생들에 평균을 구하는 함수를 만들고 평균을 출력하세요.
def average(d):
    #print(d[0]['score']['math'])
    #Code를 작성하세요.
    return 100
print(average(sample))

#2. 모든 회원의 나이 평균을 구하는 함수를 만들고 평균을 출력하세요.
def ageaverage(d):
    #print(d[0]['score']['math'])
    #Code를 작성하세요.
    return 100
print(ageaverage(sample))
