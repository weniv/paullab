'''
https://www.json-generator.com/
사이트에서 생성한 json 형식의 자료 입니다. 공식은 아래와 같습니다.
[
  '{{repeat(5, 20)}}',
  {
    _id: '{{objectId()}}',
    index: '{{index()}}',
    age: '{{integer(20, 40)}}',
    eyeColor: '{{random("blue", "brown", "green")}}',
    name: '{{firstName()}} {{surname()}}',
    gender: '{{gender()}}',
    company: '{{company().toUpperCase()}}',
    email: '{{email()}}',
    score: {
      math: '{{integer(0, 100)}}',
      science: '{{integer(0, 100)}}',
      english: '{{integer(0, 100)}}'
    }
  }
]
'''
# --- 데이터 ---
sample = [
  {
    "_id": "5c6951b9a9bad8bb977efc21",
    "index": 0,
    "age": 35,
    "eyeColor": "brown",
    "name": "Emilia Farrell",
    "gender": "female",
    "company": "ZAYA",
    "email": "emiliafarrell@zaya.com",
    "score": {
      "math": 29,
      "science": 74,
      "english": 32
    }
  },
  {
    "_id": "5c6951b9f8c62b43303a0a07",
    "index": 1,
    "age": 32,
    "eyeColor": "green",
    "name": "Raymond Stafford",
    "gender": "male",
    "company": "QUINEX",
    "email": "raymondstafford@quinex.com",
    "score": {
      "math": 82,
      "science": 76,
      "english": 30
    }
  },
  {
    "_id": "5c6951b9352dd4b528cf0964",
    "index": 2,
    "age": 30,
    "eyeColor": "brown",
    "name": "Jasmine Potts",
    "gender": "female",
    "company": "VURBO",
    "email": "jasminepotts@vurbo.com",
    "score": {
      "math": 25,
      "science": 78,
      "english": 64
    }
  },
  {
    "_id": "5c6951b9883b1793e2635e22",
    "index": 3,
    "age": 20,
    "eyeColor": "blue",
    "name": "Carolyn Rocha",
    "gender": "female",
    "company": "CINESANCT",
    "email": "carolynrocha@cinesanct.com",
    "score": {
      "math": 5,
      "science": 93,
      "english": 51
    }
  },
  {
    "_id": "5c6951b949cd4b38122c4c9d",
    "index": 4,
    "age": 27,
    "eyeColor": "green",
    "name": "Battle Mcpherson",
    "gender": "male",
    "company": "COMVEYOR",
    "email": "battlemcpherson@comveyor.com",
    "score": {
      "math": 42,
      "science": 56,
      "english": 13
    }
  },
  {
    "_id": "5c6951b9615fc445e79a0f41",
    "index": 5,
    "age": 38,
    "eyeColor": "green",
    "name": "Angelica Donovan",
    "gender": "female",
    "company": "MAKINGWAY",
    "email": "angelicadonovan@makingway.com",
    "score": {
      "math": 47,
      "science": 19,
      "english": 36
    }
  },
  {
    "_id": "5c6951b906b5cd5b02960282",
    "index": 6,
    "age": 25,
    "eyeColor": "blue",
    "name": "Collins Chapman",
    "gender": "male",
    "company": "SOPRANO",
    "email": "collinschapman@soprano.com",
    "score": {
      "math": 35,
      "science": 17,
      "english": 73
    }
  },
  {
    "_id": "5c6951b9f5ae4da005c7b2b0",
    "index": 7,
    "age": 33,
    "eyeColor": "blue",
    "name": "Waters Hammond",
    "gender": "male",
    "company": "TYPHONICA",
    "email": "watershammond@typhonica.com",
    "score": {
      "math": 90,
      "science": 90,
      "english": 40
    }
  },
  {
    "_id": "5c6951b93d5aceb5e88bfd8d",
    "index": 8,
    "age": 25,
    "eyeColor": "blue",
    "name": "Marian Oneill",
    "gender": "female",
    "company": "QOT",
    "email": "marianoneill@qot.com",
    "score": {
      "math": 71,
      "science": 27,
      "english": 74
    }
  },
  {
    "_id": "5c6951b9626c8f0617121a82",
    "index": 9,
    "age": 37,
    "eyeColor": "green",
    "name": "Ophelia Brooks",
    "gender": "female",
    "company": "QUANTASIS",
    "email": "opheliabrooks@quantasis.com",
    "score": {
      "math": 13,
      "science": 2,
      "english": 86
    }
  },
  {
    "_id": "5c6951b9a27951862ebeb9f1",
    "index": 10,
    "age": 28,
    "eyeColor": "blue",
    "name": "Florence Burnett",
    "gender": "female",
    "company": "BILLMED",
    "email": "florenceburnett@billmed.com",
    "score": {
      "math": 3,
      "science": 2,
      "english": 12
    }
  },
  {
    "_id": "5c6951b9394eca60be119fab",
    "index": 11,
    "age": 25,
    "eyeColor": "blue",
    "name": "Kimberley Allen",
    "gender": "female",
    "company": "XUMONK",
    "email": "kimberleyallen@xumonk.com",
    "score": {
      "math": 3,
      "science": 0,
      "english": 81
    }
  },
  {
    "_id": "5c6951b9ffa38396a8987cdb",
    "index": 12,
    "age": 33,
    "eyeColor": "brown",
    "name": "Jane Noble",
    "gender": "female",
    "company": "OCEANICA",
    "email": "janenoble@oceanica.com",
    "score": {
      "math": 30,
      "science": 100,
      "english": 98
    }
  },
  {
    "_id": "5c6951b9bd1d638a11ea26b7",
    "index": 13,
    "age": 35,
    "eyeColor": "blue",
    "name": "Belinda Richards",
    "gender": "female",
    "company": "COFINE",
    "email": "belindarichards@cofine.com",
    "score": {
      "math": 54,
      "science": 78,
      "english": 84
    }
  },
  {
    "_id": "5c6951b9eabc73209ca1c51d",
    "index": 14,
    "age": 40,
    "eyeColor": "brown",
    "name": "Debora Patrick",
    "gender": "female",
    "company": "EXOSTREAM",
    "email": "deborapatrick@exostream.com",
    "score": {
      "math": 37,
      "science": 63,
      "english": 28
    }
  },
  {
    "_id": "5c6951b91743bf23c4197278",
    "index": 15,
    "age": 30,
    "eyeColor": "brown",
    "name": "Mercado Collins",
    "gender": "male",
    "company": "GEEKFARM",
    "email": "mercadocollins@geekfarm.com",
    "score": {
      "math": 20,
      "science": 71,
      "english": 68
    }
  }
]
