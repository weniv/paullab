



const header = document.querySelector('#header');
const sidebox = document.querySelector('.sidebox');
const variableWidth = document.querySelectorAll('.contents_box .contents');
const delegation = document.querySelector('.contents_box');




function delegationFunc(e){

  let elem = e.target;

  console.log(elem);

  while(!elem.getAttribute('data-name')){
    elem = elem.parentNode;

    if(elem.nodeName === 'BODY'){
      elem = null;
      return;
    }
  }

  if(elem.matches('[data-name="heartbeat"]')){
    console.log('하트');
  } else if (elem.matches('[data-name="bookmark"]')) {
    console.log('북마크');
  } else if (elem.matches('[data-name="share"]')) {
    console.log('공유');
  } else if (elem.matches('[data-name="more"]')) {
    console.log('더보기');
  }

  elem.classList.toggle('on');
}

/*크기에 따라 오른쪽 사이드 바가 사라졌다 나타나도록 하는 함수*/
function resizeFunc(){

  console.log('resize');
  if(pageYOffset >= 10){

    let calcWidth = (window.innerWidth*0.5) + 167;
    console.log(window.innerWidth*0.5)

    sidebox.style.left = calcWidth + 'px';
  }

  if(matchMedia('screen and (max-width:800px)').matches){
    for (let i = 0; i < variableWidth.length; i++) {
      variableWidth[i].style.width = window.innerWidth-20+'px';
    }
  }else {
    for (let i = 0; i < variableWidth.length; i++) {
      variableWidth[i].removeAttribute('style');
    }
  }

}

/*스크롤 했을 때 로고모양, 메뉴 고정시키는 것*/
function scrollFunc(){
  console.log(pageYOffset);

  if (pageYOffset >= 10) {
    header.classList.add('on');
    if(sidebox){
      sidebox.classList.add('on');
    }

    resizeFunc();
  } else {
    header.classList.remove('on');

    if (sidebox) {
      sidebox.classList.remove('on');
      sidebox.removeAttribute('style');
    }
  }
}
/*스크롤 위치 0으로*/
setTimeout(function(){
    scrollTo(0, 0);
}, 100)

/*하트 toogle*/
if(delegation){
  delegation.addEventListener('click', delegationFunc);
}
window.addEventListener('resize', resizeFunc);
window.addEventListener('scroll', scrollFunc);
