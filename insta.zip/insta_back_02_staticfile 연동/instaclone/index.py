print("Hello Python")
