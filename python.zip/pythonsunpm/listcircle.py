inputList = input('회전 숫자와 리스트 입력 :')
splitList = inputList.split(' ')
print(splitList)

def circle(ciList):
	circleNum = int(ciList[0])
	returnList = []
	
	del ciList[0]
	print(ciList, circleNum)
	
	for i in range(circleNum):
		returnList = list(ciList[len(ciList)-i-1]) + returnList
		print(returnList)
	for j in range(len(ciList) - circleNum):
		returnList.append(ciList[j])
	return returnList

print(circle(splitList))
