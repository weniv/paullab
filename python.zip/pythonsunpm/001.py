#함수와 변수
def leehojun(x, y):
	z = x + y
	return z
print(leehojun(10, 20))
#다음(Daum)의 주가가 89,000원이고 네이버(Naver)의 주가가 751,000이라고 가정하고, 어떤 사람이 다음 주식 100주와 네이버 주식 20주를 가지고 있을 때 그 사람이 가지고 있는 주식의 총액을 계산하는 프로그램을 작성하세요.
def free():
	pass

def sumDN(daum, dStock, naver, nStock):
	return daum * dStock + naver * nStock

def desumDN(daum, dStock, daper, naver, nStock, naper):
	return (daum * dStock) * daper + (naver * nStock) * naper

print(sumDN(89000, 100, 751000, 20))
print(desumDN(89000, 100, 0.05, 751000, 20, 0.1))


