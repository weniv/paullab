#swap
x = 10
y = 20
temp = x
x = y
y = temp
x, y = y, x
