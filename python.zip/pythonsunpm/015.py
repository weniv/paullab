listx = [1, 2, 3, 4, 5]
#listy = listx[::]
listy = listx[:]
print(listy)
print(id(listx))
print(id(listy))
listy = listx[::-1]
print(listy)
