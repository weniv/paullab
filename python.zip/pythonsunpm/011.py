# int, float, str, list, tuple, dict, set, range
# 1. list
listx = [1, 2, 3, 4, 5, 6]
listy = ['a', 'b', 'c', 'd', 'e', 'f']
listz = [[1, 2, 3],[1, 2, 3],[1, 2, 3],[1, 2, 3]]
listk = [[[1, 2, 3] * 10] * 3]
listj = [(1, 2, 3), {1, 2, 3}, {'one':1, 'two':2}]
listx[0] = 100
print(listx)
print(max(listx))
print(min(listx))
del listx[0]
print(listx)

listi = listx + listy
print(listi)

listz[0][2] = 1000
print(listz)

print(listk[0][0][0])
listk[0][0][0] = 1000
print(listk)