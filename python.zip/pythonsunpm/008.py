print(str(list(range(1, 10001))).count('8'))
print(str([i for i in range(1, 10001)]).count('8'))