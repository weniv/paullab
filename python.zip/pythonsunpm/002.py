testList = [100, 200, 300, 'good']
testTuple = (100, 200, 300, 'good') + (100, 200)
testDic = {'one':1, 'two':2, 'three':3}
testSet = {1, 2, 3, 4, 5}

print(testList[2])
print(testTuple[2])
print(testDic['one'])

