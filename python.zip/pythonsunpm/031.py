f = open("new.txt", 'w')
data = 'hello world\nhello'
f.write(data)
f.close()

f = open("new.txt", 'r')
line = f.readline() #f.read() 함수를 이용해도 됩니다.
print(line)
f.close()

f = open("new.txt", 'r')
line = f.readlines()
for i in line:
	print(i)
f.close()