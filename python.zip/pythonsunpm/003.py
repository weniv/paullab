slicestr = 'paullab CEO leehojun'
slicelist = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

print(slicestr[0])
print(slicestr[0:7])
print(slicestr[:12:2])
print(slicestr[::-1])
print(slicelist[0:7])
print(slicelist[::-1])
