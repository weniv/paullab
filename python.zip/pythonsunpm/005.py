def function(n):
	if n > 1:
		return n * function(n-1)
	else:
		return n
print(function(5))
