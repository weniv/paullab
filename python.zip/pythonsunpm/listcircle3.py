def f(target1, str1):
	str1 = str1.split(' ')
	print(str1[-target1:])
	print(str1[0:-target1])
	str1 = str1[-target1:] + str1[0:-target1]
	print(" ".join(str1))

f(1, '10 20 30 40 50')
f(4, '가 나 다 라 마 바 사')
f(-2, 'A B C D E F G')
f(0, '똘기 떵이 호치 새초미')