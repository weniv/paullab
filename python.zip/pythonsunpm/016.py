fruit = {'melon':5000, 'apple':3000}
listx = [
	1,
	2,
	3,
	4,
]
#listx = [1, 2, 3, 4]

print(fruit.get('apple'))
print(fruit['apple'])

def switch1(x):
    return {
        'a': 1,
        'b': 2,
    }.get(x, 9) #default

print(fruit.keys())
print(fruit.values())
print(fruit.items())

x = [('apple', 3000), ('melon', 5000)]
for i, j in x:
	print(i, j)