for i, j in enumerate([100, 200, 300, 400, 500]):
	print(i, j)
for i, j in enumerate([100, 200, 300, 400, 500], 1):
	print(i, j)
for i, j in enumerate([100, 200, 300, 400, 500], 100):
	print(i, j)