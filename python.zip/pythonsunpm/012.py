listx = []
listy = [1, 2, 100, 3, 4]
listx.append(1)
listx.append(2)
listx.append(100)
listx.append(3)
print(listx)

print(listx.sort())
print(listx)

listx.remove(3)
print(listx)

print(listx.count(3))

listx.reverse()
print(listx)

print(listx.index(100))

listx.pop()

#for i in range(listx.count(3)):
#	listx.remove(3)

### 참고사항 ###

print(sorted(listy))
print(listy)

print(type(None))

def leehojun():
	return None

def leehojuntwo():
	pass

print(leehojuntwo())