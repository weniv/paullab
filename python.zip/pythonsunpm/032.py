def switch(num):
	return {
		1:'one',
		2:'two',
		3:'three',
		4:'four',
		5:'five',
	}.get(num, 'input 1 ~ 5 number')

print(switch(9))