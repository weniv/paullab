def leehojun(x, y):
	sumi = 0
	for i in range(x, y + 1):
		sumi = sumi + i
	return sumi
print(leehojun(100, 200))

def listsum(data):
	sumi = 0
	for i in data:
		sumi += i
	return sumi
print(listsum([100, 2, 2, 3, 4, 100, 900, 1000]))