class Car(object):
	maxSpeed = 300
	maxPeople = 5
	def move(self):
		print('움직이고 있습니다.')
	def stop(self):
		print('멈췄습니다.')
		
class HyCar(Car):
	maxSpeed = 1000
	battery = 1000
	batteryKM = 300
	
k5 = HyCar()
print(k5.maxSpeed)
print(k5.batteryKM)
	