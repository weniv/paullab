listx = [1, 3, 4, 8, 13, 17, 20]
x = []
for i in range(len(listx) - 1):
	x.append(listx[i + 1] - listx[i])
minListxIdex = x.index(min(x))
print(listx[minListxIdex], listx[minListxIdex + 1])
