score = 90
money = 0
if score >= 90:
	print('mom : i\'m so happy')
	money += 100000
elif score >= 80:
	print('mom : i\'m so happy')
	money += 80000
elif score >= 70:
	print('mom : i\'m so happy')
	money += 60000
else:
	print('mom : i\'m so bad')
	money = 0
print(money)