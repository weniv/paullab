# int, float, str, list, tuple, dict, set, range
# 2. dict
운동선수 = {'축구':'박지성', '피겨':'김연아', '역도':'장미란'}
print(운동선수['축구'])

del 운동선수['축구']
print(운동선수)

print(len(운동선수))
