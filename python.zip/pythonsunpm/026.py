#import profile
from profile import leehojunAge
x = 10
y = 20
#print(x + y + profile.leehojunAge)
print(x + y + leehojunAge)