for i in range(2, 10):
	for j in range(10):
		print('{} X {} = {}'.format(i, j, i*j))

listx = ['{} X {} = {}'.format(i, j, i*j) 
		 for i in range(2, 10) 
		 	for j in range(10)]
print(listx)