inputList = input('회전 숫자와 리스트 입력 :')
splitList = inputList.split(' ')
print(splitList)

def circle(ciList):
	rot = ciList[0]
	del ciList[0]
	
	for i in range(int(rot)):
		a = ciList[0]
		del ciList[0]
		ciList.append(a)
	
	return ciList

print(circle(splitList))