math = [
	('A군', 90),
	('B군', 80),
	('C군', 70),
	('D군', 67),
	('E군', 98),
]
for i in math:
	print(i)
	
for i, j in math:
	print(i, j)