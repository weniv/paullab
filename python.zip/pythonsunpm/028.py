x = []
for i in range(2, 101, 2):
	x.append(i)
print(x)
print([j for j in range(2, 101, 2)])
print(['{} X {} = {}'.format(i, j, i*j) 
	   for i in range(2, 10) 
	       for j in range(1, 10)])
