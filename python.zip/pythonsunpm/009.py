#3과 5의 모든 배수의 합 구하기
#3, 6, 9, 12, 15, 18
#5, 10, 15, 20

#함수이름 : mulSum
#input : 모든 배수의 합을 구할 2개의 수
#output : 20이하의 모든 배수의 합

def mulSum(x, y):
	sumi = 0
	for i in range(1, 21):
		if((i % x == 0) or (i % y == 0)):
			sumi += i
	return sumi

print(mulSum(3, 5))


