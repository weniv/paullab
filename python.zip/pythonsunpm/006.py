#for, while
print(type(range(3)))
for i in [100, 200, 300, 400, 500]:
	print(i)

for i in range(6):
	print(i)

for i in range(100, 110):
	print(i)

for i in range(100, 601, 100):
	print(i)

