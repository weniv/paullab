def sumThree():
	sumthree = 0
	for i in range(1, 21):
		if i % 3 == 0:
			sumthree += i
	return sumthree

def sumFive():
	sumfive = 0
	for i in range(1, 21):
		if i % 3 == 0:
			sumfive += i
	return sumfive

def sumCommon():
	sumcommon = 0
	for i in range(1, 21):
		if i % 15 == 0:
			sumcommon += i
	return sumcommon

print(sumThree() + sumFive() - sumCommon())