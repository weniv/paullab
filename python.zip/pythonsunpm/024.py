#특별 메서드(magic method)

class 사람:
	def __init__(self, name):
		self.name = name
	def newname(self, name):
		self.name = name
	def __getattr__(self, miss):
		print(miss + '속성은 없습니다.')
#hojun = 사람()
hojun = 사람('호준')
print(hojun.name)
print(hojun.age)
