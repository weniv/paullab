seoulFruit = {'melon':5000, 'apple':3000}
jejuFruit = seoulFruit
jejuFruit['melon'] = 10000
print(seoulFruit) #{'melon':10000, 'apple':3000}
jejuFruit = seoulFruit.copy()
print(id(jejuFruit))
print(id(seoulFruit))
print(seoulFruit)
x = 10
y = x
z = y
print(z)