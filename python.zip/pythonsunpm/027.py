x = 1
while x < 3: #여기서 3이 아닌 6으로 바꿔보세요.
	print(x)
	x += 1
	if x == 5:
		break
else:
	print('good job')