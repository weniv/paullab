from django.shortcuts import render
from .models import Blog

def index(request):
    return render(request, 'main/index.html')

def blog(request):
    bloglist = Blog.objects.all()
    return render(request, 'main/blog.html', {'bloglist' : bloglist})