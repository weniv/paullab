var data = [
    {
      "_id": "60e00ecaa22181721330c488",
      "index": 0,
      "age": 21,
      "eyeColor": "blue",
      "name": "Navarro Lindsey",
      "gender": "male"
    },
    {
      "_id": "60e00eca40760320c14ecb77",
      "index": 1,
      "age": 23,
      "eyeColor": "brown",
      "name": "Parsons Heath",
      "gender": "male"
    },
    {
      "_id": "60e00eca1ed62fbf234483ec",
      "index": 2,
      "age": 32,
      "eyeColor": "brown",
      "name": "Melva Hester",
      "gender": "female"
    },
    {
      "_id": "60e00ecaa455364bf8944905",
      "index": 3,
      "age": 26,
      "eyeColor": "blue",
      "name": "Jami Lane",
      "gender": "female"
    },
    {
      "_id": "60e00ecadbae2917fbc46e8a",
      "index": 4,
      "age": 27,
      "eyeColor": "blue",
      "name": "Long Pickett",
      "gender": "male"
    }
  ]