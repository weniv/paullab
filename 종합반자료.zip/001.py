import requests
# requests : 웹에서 정보를 가져오는 모듈
from bs4 import BeautifulSoup
# bs4 : 웹에서 가져온 정보를 잘게 분해하여 
#       우리가 원하는 정보에 보다 쉽게 접근할 수 있게하는 모듈(파싱한다 얘기합니다.)

url = 'https://search.naver.com/search.naver?where=nexearch&sm=top_hty&fbm=1&ie=utf8&query=%EB%B0%95%EC%8A%A4%EC%98%A4%ED%94%BC%EC%8A%A4'

response = requests.get(url) # 해당 url에서 정보를 가져오는 코드
response.encoding = 'utf-8' # 한글 변환 -> 안하면 뚫쀏뛟 이런 식으로 뜹니다.
html = response.text # 한글로 변환한 것 중 text만 가져옵니다.

soup = BeautifulSoup(html, 'html.parser') # html양식을 파싱합니다.
박스오피스 = soup.select('.name')        # 클래스 탐색('.'사용), 아이디 탐색('#'사용)

순위 = 1
for 영화명 in 박스오피스:
    print(순위, 영화명.text)
    순위 = 순위  + 1